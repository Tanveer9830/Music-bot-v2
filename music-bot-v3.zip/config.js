module.exports = {
    nodes: [{
        host: "us.krishna.kajuhost.qzz.io",    // Your Lavalink host
        password: "freelavalinkbykrishna",     // Your Lavalink password
        port: 19135,
        secure: false,
        name: "Main Node"
    }],
    spotify: {
        clientId: "a568b55af1d940aca52ea8fe02f0d93b",
        clientSecret: "e8199f4024fe49c5b22ea9a3dd0c4789"
    },
    botToken: "MTUxMjExMDIyNzQ0Nzg3MzYzNw.GhrZkR.LLnM3S-pcUqmyNBZchVwZr6RTQuT4qf04WAZxs",           // ← Put your bot token here
    embedColor: "#7B2FBE",  // Purple
    footerText: "Made by tanveer5637 • Powered by Tanveer",
};
